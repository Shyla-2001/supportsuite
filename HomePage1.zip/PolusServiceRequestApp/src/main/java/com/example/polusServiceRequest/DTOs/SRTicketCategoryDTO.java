package com.example.polusServiceRequest.DTOs;

import lombok.Data;

@Data
public class SRTicketCategoryDTO {

	private String categoryCode;
	private String categoryName;
	private String description;

}
