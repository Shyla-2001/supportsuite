package com.example.polusServiceRequest.constants;

public class SRTicketStatusConstants {

	  public static final String IN_PROGRESS = "S1";
	    public static final String ASSIGNED = "S2";
	    public static final String APPROVED = "S3";
	    public static final String REJECTED = "S4";
}
