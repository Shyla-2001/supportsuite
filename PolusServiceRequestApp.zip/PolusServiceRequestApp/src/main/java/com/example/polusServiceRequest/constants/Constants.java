package com.example.polusServiceRequest.constants;

public class Constants {
	public static final String DEFAULT_ROLE = "PRINCIPAL_INVESTIGATOR";
}
