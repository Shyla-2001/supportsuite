package com.example.polusServiceRequest.repositories;

public interface TicketRepository {

}
