package com.example.polusServiceRequest.services;

public interface TicketService {

}
