package com.example.polusServiceRequest.DTOs;

public class CreateTicketDTO {

}
