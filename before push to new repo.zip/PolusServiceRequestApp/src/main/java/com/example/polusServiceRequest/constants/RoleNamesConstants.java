package com.example.polusServiceRequest.constants;

public class RoleNamesConstants {
	public static final String DEFAULT_ROLE = "PRINCIPAL_INVESTIGATOR";
}
