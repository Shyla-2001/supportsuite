package com.example.polusServiceRequest.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.polusServiceRequest.models.PersonEntity;

@Repository
public interface PersonRepository extends JpaRepository<PersonEntity, Long> {

	PersonEntity findByUserNameAndPassword(String userName, String password);

	PersonEntity findByUserName(String username);

	@Query("SELECT p FROM PersonEntity p JOIN p.roles r WHERE r.role.roleName = 'APPLICATION_ADMINISTRATOR'")
	List<PersonEntity> findAllApplicationAdministrators();

	@Query(value = "SELECT DISTINCT pr1.PERSON_ID " + "FROM PERSON_ROLE pr1 "
			+ "WHERE pr1.ROLE_ID = (SELECT r1.ROLE_ID FROM ROLE r1 WHERE r1.ROLE_NAME = 'PRINCIPAL_INVESTIGATOR') "
			+ "AND pr1.PERSON_ID NOT IN (" + "    SELECT pr2.PERSON_ID " + "    FROM PERSON_ROLE pr2 "
			+ "    WHERE pr2.ROLE_ID = (SELECT r2.ROLE_ID FROM ROLE r2 WHERE r2.ROLE_NAME = 'APPLICATION_ADMINISTRATOR')"
			+ ")", nativeQuery = true)
	List<Long> findPrincipalInvestigatorsNotAdmins();

//	@Query("SELECT p FROM PersonEntity p JOIN p.roles r WHERE p.personId = :personId AND r.role.roleName = :roleName")
//	PersonEntity findByPersonIdAndRoleName(@Param("personId") Long personId, @Param("roleName") Long roleId);

}
