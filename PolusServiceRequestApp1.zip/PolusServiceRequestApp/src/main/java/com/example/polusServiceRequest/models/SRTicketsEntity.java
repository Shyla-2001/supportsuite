package com.example.polusServiceRequest.models;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Data;

@Data
@Entity
@Table(name = "SR_TICKETS")
public class SRTicketsEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SR_TICKET_ID")
    private Long srTicketId;

    @ManyToOne
    @JoinColumn(name = "PERSON_ID")
    private PersonEntity person;

    @ManyToOne
    @JoinColumn(name = "CATEGORY_CODE")
    private SRTicketCategoryEntity category;

    @ManyToOne
    @JoinColumn(name = "ASSIGNED_TO")
    private PersonEntity assignedTo;

    @ManyToOne
    @JoinColumn(name = "STATUS_CODE")
    private SRTicketStatusEntity status;

    @Column(name = "DESCRIPTION", length = 255)
    private String description;

    @Column(name = "CREATE_TIMESTAMP")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createTimestamp;

    @Column(name = "UPDATE_TIMESTAMP")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateTimestamp;


}