package com.example.polusServiceRequest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PolusServiceRequestAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(PolusServiceRequestAppApplication.class, args);
	}

}
