package com.example.polusServiceRequest.DTOs;

import lombok.Data;

@Data
public class StatusDTO {
	private Long statusCode;
	private String statusDescription;

}
