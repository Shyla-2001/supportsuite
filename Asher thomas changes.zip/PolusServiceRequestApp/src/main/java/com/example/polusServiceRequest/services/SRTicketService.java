package com.example.polusServiceRequest.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.example.polusServiceRequest.DTOs.ServiceTicketDTO;
import com.example.polusServiceRequest.DTOs.TicketResponseDTO;

public interface SRTicketService {

	Boolean deleteServiceTicket(Long ticketId);

	List<TicketResponseDTO> getServiceTickets(Long personID, Long statusType, Long pageNumber, Long pageSize);

	ResponseEntity<Object> createOrEditServiceTicket(ServiceTicketDTO ticketDTO);
	
	Boolean ticketStatusChangeToAssigned(ServiceTicketDTO ticketDTO);

}
