package com.example.polusServiceRequest.services;

import java.util.List;

import com.example.polusServiceRequest.DTOs.SRTicketCategoryDTO;

public interface SRTicketCategoryService {
	
	List<SRTicketCategoryDTO> getAllCategories();
}
