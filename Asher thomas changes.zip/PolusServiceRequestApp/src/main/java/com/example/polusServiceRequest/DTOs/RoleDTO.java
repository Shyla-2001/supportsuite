package com.example.polusServiceRequest.DTOs;

import lombok.Data;

@Data
public class RoleDTO {

	private Long roleId;
	private String roleName;
	private String roleDescription;

}
