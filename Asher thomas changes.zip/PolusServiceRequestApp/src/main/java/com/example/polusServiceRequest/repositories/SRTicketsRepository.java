package com.example.polusServiceRequest.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.polusServiceRequest.models.SRTicketsEntity;

public interface SRTicketsRepository extends JpaRepository<SRTicketsEntity, Long> {

	@Query(value = "SELECT * FROM sr_tickets t WHERE t.person_id = :personId AND t.status_code = :statusCode LIMIT :limit OFFSET :offset", nativeQuery = true)
    List<SRTicketsEntity> findServiceTicketsByPersonId(@Param("personId") Long personId,
                                                       @Param("statusCode") Long statusCode,
                                                       @Param("limit") Long limit,
                                                       @Param("offset") Long offset);

}
