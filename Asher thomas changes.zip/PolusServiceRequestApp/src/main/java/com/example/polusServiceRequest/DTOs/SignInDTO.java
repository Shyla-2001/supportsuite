package com.example.polusServiceRequest.DTOs;

import lombok.Data;

@Data
public class SignInDTO {

	private String userName;
	private String password;

}
