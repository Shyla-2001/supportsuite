package com.example.polusServiceRequest.DTOs;

import lombok.Data;

@Data
public class AdminDTO {

	private Long personId;
	private String firstName;
	private String lastName;

}
