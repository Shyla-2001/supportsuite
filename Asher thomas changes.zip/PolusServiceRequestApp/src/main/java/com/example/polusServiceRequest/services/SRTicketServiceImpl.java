package com.example.polusServiceRequest.services;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.polusServiceRequest.DTOs.AdminDTO;
import com.example.polusServiceRequest.DTOs.SRTicketCategoryDTO;
import com.example.polusServiceRequest.DTOs.ServiceTicketDTO;
import com.example.polusServiceRequest.DTOs.StatusDTO;
import com.example.polusServiceRequest.DTOs.TicketResponseDTO;
import com.example.polusServiceRequest.constants.SRTicketStatusConstants;
import com.example.polusServiceRequest.models.PersonEntity;
import com.example.polusServiceRequest.models.SRTicketCategoryEntity;
import com.example.polusServiceRequest.models.SRTicketHistoryEntity;
import com.example.polusServiceRequest.models.SRTicketStatusEntity;
import com.example.polusServiceRequest.models.SRTicketsEntity;
import com.example.polusServiceRequest.repositories.PersonRepository;
import com.example.polusServiceRequest.repositories.SRTicketCategoryRepository;
import com.example.polusServiceRequest.repositories.SRTicketHistoryRepository;
import com.example.polusServiceRequest.repositories.SRTicketStatusRepository;
import com.example.polusServiceRequest.repositories.SRTicketsRepository;

@Service
public class SRTicketServiceImpl implements SRTicketService {

	@Autowired
	private SRTicketsRepository ticketsRepository;

	@Autowired
	private SRTicketHistoryRepository historyRepository;

	@Autowired
	private PersonRepository personRepository;

	@Autowired
	private SRTicketStatusRepository statusRepository;

	@Autowired
	private SRTicketCategoryRepository categoryRepository;

	@Override
	public Boolean deleteServiceTicket(Long ticketId) {
		try {
			SRTicketsEntity ticket = ticketsRepository.findById(ticketId)
					.orElseThrow(() -> new RuntimeException("Ticket not found"));
			historyRepository.deleteBySrTicket(ticket);
			ticketsRepository.delete(ticket);
			return true;
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	@Override
	public List<TicketResponseDTO> getServiceTickets(Long personID, Long statusType, Long pageNumber, Long pageSize) {

		try {
			Long offset = pageNumber * pageSize;
			List<SRTicketsEntity> tickets = ticketsRepository.findServiceTicketsByPersonId(personID, statusType,
					pageSize, offset);
			List<TicketResponseDTO> ticketDTOs = new ArrayList<>();

			for (SRTicketsEntity ticket : tickets) {
				TicketResponseDTO dto = new TicketResponseDTO();
				dto.setTicketId(ticket.getSrTicketId());
				dto.setCategory(getCategoryDetails(ticket.getCategory()));
				dto.setRequestDescription(ticket.getDescription());
				dto.setStatusDescription(getStatusDetails(ticket.getStatus()));//
				dto.setCreateTimestamp(ticket.getCreateTimestamp());
				dto.setUpdateTimestamp(ticket.getUpdateTimestamp());
				if (!statusType.equals(SRTicketStatusConstants.IN_PROGRESS))
					dto.setAssignedTo(getAdminDetails(ticket.getAssignedTo()));
				ticketDTOs.add(dto);
			}
			return ticketDTOs;
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	@Override
	public ResponseEntity<Object> createOrEditServiceTicket(ServiceTicketDTO ticketDTO) {

		try {
			boolean actionCompleted;
			Map<String, String> response = new HashMap<>();

			if (ticketDTO.getTicketId() == null) {
				actionCompleted = createNewServiceTicket(ticketDTO);
				if (actionCompleted)
					response.put("message", "Ticket Created Successfully.");
				else
					response.put("message", "Ticket Created Failed.");
				return ResponseEntity.status(HttpStatus.CREATED).body(response);
			}
			actionCompleted = updateInProgressServiceTicket(ticketDTO);
			if (actionCompleted)
				response.put("message", "Ticket Edited Successfully.");
			else
				response.put("message", "Ticket Edited Failed.");
			return ResponseEntity.status(HttpStatus.CREATED).body(response);

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());

		}
	}

	@Override
	public Boolean ticketStatusChangeToAssigned(ServiceTicketDTO ticketDTO) {

		try {
			SRTicketsEntity ticket = ticketsRepository.findById(ticketDTO.getTicketId())
					.orElseThrow(() -> new RuntimeException("Ticket not found"));

			PersonEntity admin = personRepository.findById(ticketDTO.getAssignedTo())
					.orElseThrow(() -> new RuntimeException("Admin not found"));

			SRTicketStatusEntity status = statusRepository.findById(SRTicketStatusConstants.ASSIGNED).orElseThrow(() -> new RuntimeException("Status not found"));
			if (status == null) {
				throw new RuntimeException("Initial status not found");
			}

			ticket.setAssignedTo(admin);
			ticket.setUpdateTimestamp(Timestamp.from(Instant.now()));
			ticket.setStatus(status);
			ticket = ticketsRepository.save(ticket);

			SRTicketHistoryEntity history = new SRTicketHistoryEntity();
			history.setSrTicket(ticket);
			history.setStatusCode(ticket.getStatus());
			history.setUpdateUser(ticket.getPerson());
			history.setUpdateTimestamp(Timestamp.from(Instant.now()));
			historyRepository.save(history);
			return true;
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	private AdminDTO getAdminDetails(PersonEntity person) {

		AdminDTO adminDTO = new AdminDTO();
		adminDTO.setPersonId(person.getPersonId());
		adminDTO.setFirstName(person.getFirstName());
		adminDTO.setLastName(person.getLastName());
		return adminDTO;
	}
	
	private StatusDTO getStatusDetails(SRTicketStatusEntity status) {

		StatusDTO dto = new StatusDTO();
		dto.setStatusCode(status.getStatusCode());
		dto.setStatusDescription(status.getStatusDescription());
		return dto;
	}
	
	private SRTicketCategoryDTO getCategoryDetails(SRTicketCategoryEntity category) {

		SRTicketCategoryDTO dto = new SRTicketCategoryDTO();
		dto.setCategoryCode(category.getCategoryCode());
		dto.setCategoryName(category.getCategoryName());
		dto.setDescription(category.getDescription());
		return dto;
	}

	private boolean createNewServiceTicket(ServiceTicketDTO ticketDTO) {

		PersonEntity user = personRepository.findById(ticketDTO.getPersonId())
				.orElseThrow(() -> new RuntimeException("User not found"));
		SRTicketCategoryEntity category = categoryRepository.findById(ticketDTO.getCategory())
				.orElseThrow(() -> new RuntimeException("Category not found"));

		SRTicketsEntity ticket = new SRTicketsEntity();
		ticket.setPerson(user);
		ticket.setCategory(category);
		ticket.setDescription(ticketDTO.getRequestDescription());
		ticket.setCreateTimestamp(Timestamp.from(Instant.now()));
		ticket.setUpdateTimestamp(ticket.getCreateTimestamp()); // Initial update timestamp same as create timestamp
		SRTicketStatusEntity status = statusRepository.findById(SRTicketStatusConstants.IN_PROGRESS).orElseThrow(() -> new RuntimeException("Status not found"));
		ticket.setStatus(status);
		ticket = ticketsRepository.save(ticket);
		SRTicketHistoryEntity history = new SRTicketHistoryEntity();
		history.setSrTicket(ticket);
		history.setStatusCode(status);
		history.setUpdateUser(user);
		history.setUpdateTimestamp(Timestamp.from(Instant.now()));
		historyRepository.save(history);
		return true;

	}

	private boolean updateInProgressServiceTicket(ServiceTicketDTO updateDTO) {

		SRTicketsEntity ticket = ticketsRepository.findById(updateDTO.getTicketId())
				.orElseThrow(() -> new RuntimeException("Ticket not found"));

		SRTicketCategoryEntity category = categoryRepository.findById(updateDTO.getCategory())
				.orElseThrow(() -> new RuntimeException("Category not found"));

		ticket.setCategory(category);
		ticket.setDescription(updateDTO.getRequestDescription());
		ticket.setUpdateTimestamp(Timestamp.from(Instant.now()));
		ticket = ticketsRepository.save(ticket);

		SRTicketHistoryEntity history = new SRTicketHistoryEntity();
		history.setSrTicket(ticket);
		history.setStatusCode(ticket.getStatus());
		history.setUpdateUser(ticket.getPerson());
		history.setUpdateTimestamp(Timestamp.from(Instant.now()));
		historyRepository.save(history);
		return true;
	}
}
