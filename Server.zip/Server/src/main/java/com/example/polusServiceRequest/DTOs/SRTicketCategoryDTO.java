package com.example.polusServiceRequest.DTOs;

import lombok.Data;

@Data
public class SRTicketCategoryDTO {

	private Long categoryCode;
	private String categoryName;
	private String description;

}
